i = 0
while i <= 12: 
    print(str(i) + ':oo am',str(i) + ':oo pm' )
    i = i + 1