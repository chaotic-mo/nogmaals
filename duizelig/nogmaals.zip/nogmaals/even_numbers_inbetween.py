i = 18
while i <= 48:
    i = i + 2
    print(i)