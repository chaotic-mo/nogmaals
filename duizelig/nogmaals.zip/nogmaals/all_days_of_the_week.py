'''
# i = input('') 
#while i == ['maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag', 'zondag']:
    print(i)
'''
days = 0
week = ['maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag', 'zondag']
while days < 7:
    print("Today is", week[days])
    days += 1