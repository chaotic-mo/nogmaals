print('lanching in: ')
i = 31
while i > 0:
    i = i - 1
    print(i)
print('We have lift off!! ')
    